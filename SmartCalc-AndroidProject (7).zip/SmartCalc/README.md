# SmartCalc - Android Studio project

1. Android Studio (latest stable) mein File > Open > is folder ko chunein, Gradle sync hone dein.
2. app/build.gradle.kts mein applicationId badlein (e.g. com.yourname.smartcalc).
3. Run button se phone/emulator par test karein (test ads dikhengi).
4. Release se pehle AdMob IDs badlein:
   - AndroidManifest.xml -> APPLICATION_ID (App ID, "~" wali)
   - MainActivity.kt -> BANNER_AD_UNIT_ID (Banner unit, "/" wali)
5. Build > Generate Signed App Bundle / APK > Android App Bundle (.aab). Keystore sambhal kar rakhein.
6. Play Console > Create app > Production/Testing track par .aab upload karein.
