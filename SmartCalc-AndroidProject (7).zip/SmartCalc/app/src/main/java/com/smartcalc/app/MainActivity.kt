package com.smartcalc.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

// Test banner ID. Publish se pehle apni real AdMob banner unit ID lagayen.
private const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setContent { CalcScreen() }
    }
}

/* ---------------- Expression parser ---------------- */

private class Parser(private val s: String, private val deg: Boolean) {
    private var i = 0

    fun parse(): Double {
        val v = expr()
        if (i < s.length) throw IllegalArgumentException("Bad input")
        return v
    }

    private fun peek(): Char = if (i < s.length) s[i] else '\u0000'
    private fun eat(c: Char): Boolean { if (peek() == c) { i++; return true }; return false }

    private fun expr(): Double {
        var v = term()
        while (true) {
            v = if (eat('+')) v + term()
            else if (eat('−') || eat('-')) v - term()
            else return v
        }
    }

    private fun term(): Double {
        var v = power()
        while (true) {
            if (eat('×') || eat('*')) v *= power()
            else if (eat('÷') || eat('/')) v /= power()
            else if (peek() == '(' || peek() == '√' || peek().isLetter()) v *= power() // implicit: 2(3), 2π
            else return v
        }
    }

    private fun power(): Double {
        val base = unary()
        return if (eat('^')) base.pow(power()) else base // right-associative
    }

    private fun unary(): Double = when {
        eat('−') || eat('-') -> -unary()
        eat('+') -> unary()
        else -> postfix()
    }

    private fun postfix(): Double {
        var v = primary()
        while (true) {
            if (eat('%')) v /= 100.0
            else if (eat('!')) v = factorial(v)
            else break
        }
        return v
    }

    private fun primary(): Double {
        if (eat('(')) { val v = expr(); eat(')'); return v }
        if (eat('√')) return sqrt(postfix())
        if (peek().isDigit() || peek() == '.') {
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            return s.substring(st, i).toDouble()
        }
        if (peek().isLetter()) {
            val st = i
            while (peek().isLetter()) i++
            val name = s.substring(st, i)
            return when (name) {
                "π" -> PI
                "e" -> E
                else -> {
                    val arg = if (eat('(')) { val v = expr(); eat(')'); v } else postfix()
                    val r = if (deg) Math.toRadians(arg) else arg
                    when (name) {
                        "sin" -> sin(r)
                        "cos" -> cos(r)
                        "tan" -> tan(r)
                        "ln" -> ln(arg)
                        "log" -> log10(arg)
                        else -> throw IllegalArgumentException("Unknown: $name")
                    }
                }
            }
        }
        throw IllegalArgumentException("Unexpected")
    }

    private fun factorial(n: Double): Double {
        if (n < 0 || n != floor(n) || n > 170) throw IllegalArgumentException("Bad factorial")
        var r = 1.0
        for (k in 2..n.toInt()) r *= k
        return r
    }
}

private fun format(d: Double): String {
    if (d.isNaN() || d.isInfinite()) throw ArithmeticException("Bad result")
    val clean = if (abs(d) < 1e-12) 0.0 else d
    if (abs(clean) >= 1e15 || (clean != 0.0 && abs(clean) < 1e-9)) {
        return String.format("%.9E", clean).replace(Regex("\\.?0+E"), "E")
    }
    return BigDecimal(clean).round(MathContext(12)).stripTrailingZeros().toPlainString()
}

fun evaluate(input: String, deg: Boolean): String? = try {
    format(Parser(input, deg).parse())
} catch (e: Exception) { null }

/* ---------------- UI ---------------- */

private val BgColor = Color(0xFF1B1B1F)
private val NumColor = Color(0xFF2B2B30)
private val OpColor = Color(0xFF3A4A66)
private val AccentColor = Color(0xFF8AB4F8)
private val SciColor = Color(0xFF232328)

@Composable
fun CalcScreen() {
    var expr by rememberSaveable { mutableStateOf("") }
    var deg by rememberSaveable { mutableStateOf(true) }
    var sci by rememberSaveable { mutableStateOf(false) }
    val preview = remember(expr, deg) {
        if (expr.isEmpty()) "" else evaluate(expr, deg)?.takeIf { it != expr } ?: ""
    }

    fun press(k: String) {
        when (k) {
            "AC" -> expr = ""
            "⌫" -> expr = expr.dropLast(1)
            "=" -> evaluate(expr, deg)?.let { expr = it }
            "sin", "cos", "tan", "ln", "log" -> expr += "$k("
            "√" -> expr += "√("
            "Deg" -> deg = !deg
            "Rad" -> deg = !deg
            else -> expr += k
        }
    }

    Column(
        Modifier.fillMaxSize().background(BgColor).statusBarsPadding().navigationBarsPadding()
    ) {
        // Display
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            Text(
                expr.ifEmpty { "0" },
                color = Color.White,
                fontSize = if (expr.length > 14) 34.sp else 52.sp,
                textAlign = TextAlign.End,
                maxLines = 2
            )
            Text(preview, color = Color(0xFF9AA0A6), fontSize = 28.sp, maxLines = 1)
            Spacer(Modifier.height(12.dp))
        }

        // Scientific toggle row
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Key(if (sci) "▲" else "▼", SciColor, Modifier.weight(1f)) { sci = !sci }
            Key(if (deg) "Deg" else "Rad", SciColor, Modifier.weight(1f)) { deg = !deg }
        }

        if (sci) {
            KeyRow(listOf("sin", "cos", "tan", "π", "e"), SciColor, ::press)
            KeyRow(listOf("ln", "log", "√", "^", "!"), SciColor, ::press)
        }

        KeyRow(listOf("AC", "(", ")", "÷"), OpColor, ::press, firstColor = OpColor)
        KeyRow(listOf("7", "8", "9", "×"), NumColor, ::press, opIndex = 3)
        KeyRow(listOf("4", "5", "6", "−"), NumColor, ::press, opIndex = 3)
        KeyRow(listOf("1", "2", "3", "+"), NumColor, ::press, opIndex = 3)
        KeyRow(listOf("0", ".", "⌫", "="), NumColor, ::press, accentIndex = 3)

        AdBanner()
    }
}

@Composable
private fun KeyRow(
    keys: List<String>,
    color: Color,
    onPress: (String) -> Unit,
    firstColor: Color? = null,
    opIndex: Int = -1,
    accentIndex: Int = -1
) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        keys.forEachIndexed { idx, k ->
            val c = when {
                idx == accentIndex -> AccentColor
                idx == opIndex || (idx == 3 && keys.size == 4 && k != "=") -> OpColor
                idx == 0 && firstColor != null -> firstColor
                else -> color
            }
            Key(k, c, Modifier.weight(1f), dark = idx == accentIndex) { onPress(k) }
        }
    }
}

@Composable
private fun Key(
    label: String,
    color: Color,
    modifier: Modifier,
    dark: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier
            .padding(4.dp)
            .height(64.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (dark) Color.Black else Color.White, fontSize = 24.sp)
    }
}

@Composable
private fun AdBanner() {
    AndroidView(
        modifier = Modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = BANNER_AD_UNIT_ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
